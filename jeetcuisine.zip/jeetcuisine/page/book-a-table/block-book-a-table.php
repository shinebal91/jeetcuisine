<h1><?php echo $lang['BookTables']; ?></h1>
<div class="img-url-holder">
	<div class="img-url">
		<img src="<?php echo $CONF['installation_path']; ?>skin/images/2book-a-table.jpg" alt="<?php echo $lang['BookTables']; ?>" />
		<div class="url-holder">
			<a class="text-center" href="<?php echo $CONF['installation_path']; ?>page/book-a-table/" title="<?php echo $lang['BookTables']; ?>"><?php echo $lang['BookTables']; ?></a>
            <i class="fa fa-th-large"></i>
		</div>
	</div>
</div>

<div class="container" id="select-menu">
	<div class="col-md-12 content_menus_with_details" style="margin-bottom:0px;" id="menuset">
	<h1 style="text-align:center">CHOOSE YOUR MENU SET</h1>
	<div class="col-md-6">
	<table class="table table-bordered table-responsive ">
    <thead style="text-align:center">
      <tr>
        <th style="text-align:center"><strong>MENU SET A</strong></th>
      </tr>
    </thead>
    <tbody>
      <tr>
			<td>
			Choice of 2 Appetizers.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 2 Curries.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Indian Bread.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Rice.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Raita.
			</td>
	  </tr>
	  <tr>
			<td>
			Choice of 1 Dessert.
			</td>
      </tr>
	  <tr>
			<td>
			Plus Salad.
			</td>
      </tr>
	  
    </tbody>
  </table>
  </div><!--Menu Set A-->
  
  <div class="col-md-6">
	<table class="table table-bordered table-responsive ">
    <thead style="text-align:center">
      <tr>
        <th style="text-align:center"><strong>MENU SET B</strong></th>
      </tr>
    </thead>
    <tbody>
      <tr>
			<td>
			Choice of 3 Appetizers.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 3 Curries.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Indian Bread.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Rice.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Raita.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Dessert.
			</td>
      </tr>
	  <tr>
			<td>
			Choice of 1 Drink.
			</td>
      </tr>
	  <tr>
			<td>
			Plus Salad and Papad.
			</td>
      </tr>
    </tbody>
  </table>
  </div><!--Menu Set B-->
  
  </div><!--Menu Sets-->
  
  
  
  <div class="col-md-12 content_menus_with_details" id="menuprice">
	<h1 style="text-align:center">MENU PRICES</h1>
	<div class="col-md-6">
	<table class="table table-bordered table-responsive ">
    <thead style="text-align:center">
      <tr>
        <th style="text-align:center" colspan=2><strong>MENU SET A PRICE</strong></th>
      </tr>
	  
	  <tr>
        <th style="text-align:center"><strong>AGE GROUP</strong></th>
		<th style="text-align:center"><strong>PRICE PER HEAD (in Yen)*</strong></th>
      </tr>
    </thead>
    <tbody>
      <tr>
			<td>Adult</td>
			<td>1950</td>
      </tr>
	  <tr>
			<td>Child (4-6 yrs)</td>
			<td>500</td>
      </tr>
	  <tr>
			<td>Child (7-12 yrs)</td>
			<td>1000</td>
      </tr>
	  
    </tbody>
  </table>
  
	<div class="col-md-12" style="text-align:center; padding-bottom:10px;">
		<a class="btn btn-success btn-block" id="btnA" href="menu-order.php?menuid=1">SELECT MENU SET A</a>
	</div>
	
  </div><!--Menu Price A-->
  
  <div class="col-md-6">
	<table class="table table-bordered table-responsive ">
    <thead style="text-align:center">
      <tr>
        <th style="text-align:center" colspan=2><strong>MENU SET B PRICE</strong></th>
      </tr>
	  
	  <tr>
        <th style="text-align:center"><strong>AGE GROUP</strong></th>
		<th style="text-align:center"><strong>PRICE PER HEAD (in Yen)*</strong></th>
      </tr>
    </thead>
    <tbody>
      <tr>
			<td>Adult</td>
			<td>2250</td>
      </tr>
	  <tr>
			<td>Child (4-6 yrs)</td>
			<td>500</td>
      </tr>
	  <tr>
			<td>Child (7-12 yrs)</td>
			<td>1000</td>
      </tr>
	  
    </tbody>
  </table>
  
	<div class="col-md-12" style="text-align:center; padding-bottom:10px;">
		<a class="btn btn-success btn-block" id="btnB" href="menu-order.php?menuid=2" >SELECT MENU SET B</a>
	</div>
  
  </div><!--Menu Price B-->
  *Inclusive of all taxes.
  </div><!--Menu Prices-->

</div><!--END SELECT MENU-->

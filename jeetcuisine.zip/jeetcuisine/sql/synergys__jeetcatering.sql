-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Nov 26, 2015 at 02:06 PM
-- Server version: 5.6.27
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `synergys__jeetcatering`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `event_id` int(10) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(100) NOT NULL,
  `event_location` varchar(100) NOT NULL,
  `event_thumbnail` varchar(500) NOT NULL,
  `event_description` longtext NOT NULL,
  `event_date` datetime NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `informations`
--

CREATE TABLE IF NOT EXISTS `informations` (
  `contact_id` int(10) NOT NULL AUTO_INCREMENT,
  `contact_phone_number` varchar(20) NOT NULL,
  `contact_email` varchar(50) NOT NULL,
  `contact_latitude` varchar(50) NOT NULL,
  `contact_longitude` varchar(50) NOT NULL,
  `contact_address` varchar(150) DEFAULT NULL,
  `contact_monday_hours` varchar(50) NOT NULL,
  `contact_tuesday_hours` varchar(20) DEFAULT NULL,
  `contact_wednesday_hours` varchar(20) DEFAULT NULL,
  `contact_thursday_hours` varchar(20) DEFAULT NULL,
  `contact_friday_hours` varchar(20) DEFAULT NULL,
  `contact_saturday_hours` varchar(20) DEFAULT NULL,
  `contact_sunday_hours` varchar(20) DEFAULT NULL,
  `site_body_background` varchar(255) DEFAULT NULL,
  `site_button_bg_normal` varchar(15) DEFAULT NULL,
  `site_button_txt_normal` varchar(15) DEFAULT NULL,
  `site_button_txt_hover` varchar(15) DEFAULT NULL,
  `site_button_bg_hover` varchar(15) DEFAULT NULL,
  `header_top_bar_bg` varchar(15) DEFAULT NULL,
  `header_middle_section_bg` varchar(15) DEFAULT NULL,
  `header_color` varchar(15) DEFAULT NULL,
  `header_nav_bg` varchar(15) DEFAULT NULL,
  `header_nav_item_bg_hover` varchar(15) DEFAULT NULL,
  `header_nav_txt` varchar(15) DEFAULT NULL,
  `header_nav_item_txt_hover` varchar(15) DEFAULT NULL,
  `footer_top_section_bg` varchar(15) DEFAULT NULL,
  `footer_bottom_bar_txt` varchar(15) DEFAULT NULL,
  `footer_bottom_bar_bg` varchar(15) DEFAULT NULL,
  `footer_top_section_txt` varchar(15) DEFAULT NULL,
  `site_main_font` varchar(255) DEFAULT NULL,
  `language_is_active` varchar(100) DEFAULT NULL,
  `social_fb` varchar(255) DEFAULT NULL,
  `social_tw` varchar(255) DEFAULT NULL,
  `social_gplus` varchar(255) DEFAULT NULL,
  `social_dribbble` varchar(255) DEFAULT NULL,
  `social_stumbleupon` varchar(255) DEFAULT NULL,
  `social_linkedin` varchar(255) DEFAULT NULL,
  `social_pin` varchar(255) DEFAULT NULL,
  `social_tumblr` varchar(255) DEFAULT NULL,
  `social_instagram` varchar(255) DEFAULT NULL,
  `social_youtube` varchar(255) DEFAULT NULL,
  `social_flickr` varchar(255) DEFAULT NULL,
  `social_digg` varchar(255) DEFAULT NULL,
  `social_vimeo` varchar(255) DEFAULT NULL,
  `facebook_appid` varchar(255) DEFAULT NULL,
  `facebook_secret` varchar(255) DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT NULL,
  `paypal_sandbox` varchar(255) DEFAULT NULL,
  `wysiwyg_about` longtext,
  `wysiwyg_contact` longtext,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `informations`
--

INSERT INTO `informations` (`contact_id`, `contact_phone_number`, `contact_email`, `contact_latitude`, `contact_longitude`, `contact_address`, `contact_monday_hours`, `contact_tuesday_hours`, `contact_wednesday_hours`, `contact_thursday_hours`, `contact_friday_hours`, `contact_saturday_hours`, `contact_sunday_hours`, `site_body_background`, `site_button_bg_normal`, `site_button_txt_normal`, `site_button_txt_hover`, `site_button_bg_hover`, `header_top_bar_bg`, `header_middle_section_bg`, `header_color`, `header_nav_bg`, `header_nav_item_bg_hover`, `header_nav_txt`, `header_nav_item_txt_hover`, `footer_top_section_bg`, `footer_bottom_bar_txt`, `footer_bottom_bar_bg`, `footer_top_section_txt`, `site_main_font`, `language_is_active`, `social_fb`, `social_tw`, `social_gplus`, `social_dribbble`, `social_stumbleupon`, `social_linkedin`, `social_pin`, `social_tumblr`, `social_instagram`, `social_youtube`, `social_flickr`, `social_digg`, `social_vimeo`, `facebook_appid`, `facebook_secret`, `paypal_email`, `paypal_sandbox`, `wysiwyg_about`, `wysiwyg_contact`) VALUES
(1, '090-9961-5154', 'jeet.tokyo@gmail.com', '35.6627759', '139.7117328', 'Tokyo, Japan', '10:00 - 23:00', '10:00 - 23:00', '10:00 - 23:00', '10:00 - 23:00', '10:00 - 23:00', '10:00 - 23:00', '10:00 - 23:00', '#F3F0EB', '#00bc8c', '#ffffff', '#ffffff', '#008966', '#222222', '#343434', '#ffffff', '#222222', '#008966', '#ffffff', '#ffffff', '#2D2D2D', '#ffffff', '#444444', '#ffffff', 'Oswald', 'Yes', 'http://facebook.com', 'http://twitter.com', 'http://plus.google.com', 'http://dribbble.com', 'http://stumbleupon.com', 'http://linkedin.com', 'http://pinterest.com', 'http://tumblr.com', 'http://instagram.com', 'http://youtube.com', 'http://flickr.com', 'http://digg.com', 'http://vimeo.com', NULL, NULL, 'stan-merchant@gmail.com', 'Sandbox', '&lt;h2&gt;&lt;span style=&quot;font-size:24px&quot;&gt;About JeetCuisine&lt;/span&gt;&lt;/h2&gt;\r\n\r\n&lt;p style=&quot;text-align:justify&quot;&gt;&lt;span style=&quot;font-size:22px&quot;&gt;&lt;strong&gt;JeetCuisine&lt;/strong&gt; specializes in catering exquisite&amp;nbsp;Indian Delicacies.&amp;nbsp;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;blockquote&gt;\r\n&lt;p style=&quot;text-align:center&quot;&gt;&lt;span style=&quot;font-size:24px&quot;&gt;&lt;q&gt;SAVE YOUR DATE&lt;/q&gt;&lt;/span&gt;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;text-align:justify&quot;&gt;&lt;span style=&quot;font-size:22px&quot;&gt;We personalize menu&amp;rsquo;s that is perfect for your taste, budget and event. We can accommodate any dietary restrictions with style. We&amp;#39;ll guarantee that your delivery is in sync with your expectations and&amp;nbsp;you&amp;#39;ll experience the finest indian cuisine buffets.&amp;nbsp;We are the chosen caterer for many venues on their catering panels, selected by both exclusive and high profile corporate and private sectors.&amp;nbsp;&lt;/span&gt;&lt;/p&gt;\r\n\r\n&lt;blockquote&gt;\r\n&lt;p style=&quot;text-align:center&quot;&gt;&lt;span style=&quot;font-size:24px&quot;&gt;&lt;q&gt;LET US MAKE YOUR NEXT OCCASION SPECIAL&lt;/q&gt;&lt;/span&gt;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;div class=&quot;row two-col-right&quot;&gt;\r\n&lt;div class=&quot;col-md-9 col-main&quot;&gt;\r\n&lt;h3&gt;&lt;span&gt;For any queries, you can contact &lt;strong&gt;Mr. Amarjit Singh &lt;/strong&gt;(&lt;/span&gt;&lt;span&gt;ã‚¢ãƒžãƒ«ã‚¸ãƒˆ ã‚·ãƒ³ã‚°&lt;/span&gt;&lt;span&gt;)&lt;/span&gt;&lt;/h3&gt;\r\n\r\n&lt;h3&gt;Contact :&amp;nbsp;090-9961-5154&lt;/h3&gt;\r\n\r\n&lt;h3&gt;Email: jeet.tokyo@gmail.com&lt;/h3&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;div class=&quot;col-md-3 col-sidebar&quot;&gt;\r\n&lt;h2&gt;&lt;img alt=&quot;Amarjit Singh&quot; src=&quot;https://www.facebook.com/photo.php?fbid=103602113099247&amp;amp;l=a367a28f1a&quot; /&gt;&lt;/h2&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;div class=&quot;row two-col-right&quot;&gt;\r\n&lt;div class=&quot;col-md-9 col-main&quot;&gt;\r\n&lt;h3&gt;&lt;span&gt;Catering By: Ghungroo Restaurant (Aoyama)&lt;/span&gt;&lt;/h3&gt;\r\n\r\n&lt;h3 style=&quot;text-align:justify&quot;&gt;&lt;span&gt;&lt;strong&gt;Ghungroo&lt;/strong&gt; is an Indian Restaurant that provides excellent food quality and impeccable services. Our team of culinary staff will ensure that your event is executed to perfection. We bring to your table the best of what Japan has to offer. We choose the best produce available, ensuring freshness and maximum quality. We have a proud record of successful events.&lt;/span&gt;&lt;/h3&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;div class=&quot;col-md-3 col-sidebar&quot;&gt;\r\n&lt;h2&gt;&lt;img alt=&quot;Ghungroo&quot; src=&quot;https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcTL5sHQtA9-vHcsThZrbxAmYHyNVDC1UHTeadnERoiUEHGanjhWmw&quot; /&gt;&lt;/h2&gt;\r\n&lt;/div&gt;\r\n&lt;/div&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n', '&lt;p style=&quot;text-align:center&quot;&gt;&lt;span style=&quot;font-size:16px&quot;&gt;    \n\nIf you have any queries.??\n\n&lt;/span&gt;&lt;/p&gt;\n');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `menuorder`
--

CREATE TABLE IF NOT EXISTS `menuorder` (
  `menu_item_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  KEY `menu_item_id` (`menu_item_id`,`order_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menuorder`
--

INSERT INTO `menuorder` (`menu_item_id`, `order_id`) VALUES
(246, 574),
(246, 576),
(248, 576),
(252, 576),
(255, 574);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `menu_item_id` int(10) NOT NULL AUTO_INCREMENT,
  `menu_item_category` varchar(100) NOT NULL,
  `menu_item_name` varchar(100) NOT NULL,
  `menu_item_details` varchar(300) DEFAULT NULL,
  `menu_preview_image` varchar(255) NOT NULL,
  `menu_item_price_per_slice` double NOT NULL,
  `menu_item_author` varchar(100) DEFAULT NULL,
  `menu_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`menu_item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=314 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`menu_item_id`, `menu_item_category`, `menu_item_name`, `menu_item_details`, `menu_preview_image`, `menu_item_price_per_slice`, `menu_item_author`, `menu_date`) VALUES
(246, 'Appetizers', 'Samosa (2Pcs.)', 'Deep-fried patties stuffed with potato, green peas and cashew nuts', 'skin/images/menus/samosa.jpg', 500, 'Cristian Stan', NULL),
(247, 'Appetizers', 'Mix Veg. Pakora', 'Cauliflower/Potato/Onion -  Savory Fritters', 'skin/images/menus/mix_pakora.jpg', 550, 'Cristian Stan', NULL),
(248, 'Appetizers', 'Paneer Pakora', 'Cheese Savory Fritters', 'skin/images/menus/paneer_pakora.jpg', 650, 'Cristian Stan', NULL),
(251, 'Appetizers', 'Aloo Tikki', 'Tangy potato snack', 'skin/images/menus/aloo_tikki.jpg', 475, 'Prakhar Bhardwaj', NULL),
(252, 'Appetizers', 'Veg Roll', 'Mixed vegetables stuffed in tortilla', 'skin/images/menus/veg_roll.jpg', 600, 'Prakhar Bhardwaj', NULL),
(253, 'Appetizers Non Veg', 'Tandoori Chicken Tikka', 'Grilled chicken mariated in spices and yogurt', 'skin/images/menus/tandoori_chicken_tikka.jpg', 1550, 'Prakhar Bhardwaj', NULL),
(254, 'Appetizers Non Veg', 'Murg Malai Chicken Tikka', ' Skewered chicken with cheese creaminess', 'skin/images/menus/malai_tikka.jpg', 1700, 'Prakhar Bhardwaj', NULL),
(255, 'Appetizers Non Veg', 'Chicken Manchurian', 'Chicken fried with chinese spices', 'skin/images/menus/chicken_manchurian.jpg', 1550, 'Prakhar Bhardwaj', NULL),
(256, 'Appetizers Non Veg', 'Seekh Kebab', 'Meat minced with spices and grilled on skewers', 'skin/images/menus/seekh_kebab.jpg', 1550, 'Prakhar Bhardwaj', NULL),
(257, 'Appetizers Non Veg', 'Fish Tikka', 'Boneless spiced fish meat cooked in hot oven', 'skin/images/menus/fish_tikka.jpg', 1550, 'Prakhar Bhardwaj', NULL),
(258, 'Appetizers Non Veg', 'Tandoori Prawn', 'Marinated prawns in cream cheese', 'skin/images/menus/tandoori_prawn.jpg', 1990, 'Sandeep Bal', NULL),
(259, 'Curries Veg', 'Palak/Saag Paneer', 'Spinach and cheese curry', 'skin/images/menus/palak_paneer.jpg', 1470, 'Sandeep Bal', NULL),
(260, 'Curries Veg', 'Chilly Paneer', 'Capsicum and cheese curry', 'skin/images/menus/chilly_paneer.jpg', 1200, 'Sandeep Bal', NULL),
(263, 'Curries Veg', 'Kadai Paneer', 'Capsicum, onion, tomato and cheese curry', 'skin/images/menus/kadai_paneer.jpg', 1300, 'Sandeep Bal', NULL),
(264, 'Curries Veg', 'Matar Paneer', 'Green peas and cheese curry', 'skin/images/menus/matar_paneer.jpg', 1200, 'Sandeep Bal', NULL),
(265, 'Curries Veg', 'Chana Masala', 'Chick peas cooked with tomato and onion', 'skin/images/menus/chana_masala.jpg', 1200, 'Sandeep Bal', NULL),
(266, 'Curries Veg', 'Baingan Bhartha', 'Fire-roasted eggplant cooked with spices', 'skin/images/menus/baingan_bhartha.jpg', 1200, 'Sandeep Bal', NULL),
(267, 'Curries Veg', 'Malai Kofta', 'Veg balls in a thick creamy sauce', 'skin/images/menus/malai_kofta.jpg', 1200, 'Sandeep Bal', NULL),
(268, 'Curries Veg', 'Dal Makhani', 'Back lentil curry with butter-cream', 'skin/images/menus/dal_makhani1.jpg', 1200, 'Sandeep Bal', NULL),
(269, 'Curries Veg', 'Aloo Gobi', 'Cauliflower-potato dry Indian dish', 'skin/images/menus/aloo_gobi.jpg', 1200, 'Sandeep Bal', NULL),
(270, 'Curries Veg', 'Mix Vegetable', 'Carrot, beans, green peas, capsicum', 'skin/images/menus/mix_veg.jpg', 1200, 'Sandeep Bal', NULL),
(271, 'Curries Veg', 'Dal Tadka', 'Yellow lentil curry with onion and tomatoes', 'skin/images/menus/dal_tadka.jpg', 1200, 'Sandeep Bal', NULL),
(272, 'Curries Veg', 'Veg Jalfrezi', 'Indian stir-fry mixed vegetable curry', 'skin/images/menus/veg_jalfrezi.jpg', 1200, 'Sandeep Bal', NULL),
(273, 'Curries Veg', 'Nav-Ratna Korma ', 'Nine-vegetables curry', 'skin/images/menus/navratan_korma.jpg', 1200, 'Sandeep Bal', NULL),
(274, 'Curries Veg', 'Rajmah', 'Red kidney beans in a thick curry with Indian whole spices', 'skin/images/menus/rajmah.jpg', 1200, 'Sandeep Bal', NULL),
(275, 'Curries Veg', 'Aloo Zeera', 'Potato cooked with cumin seeds-dry curry', 'skin/images/menus/aloo_zeera.jpg', 1200, 'Sandeep Bal', NULL),
(276, 'Chicken Curries', 'Butter Chicken', 'Boneless chicken cooked with butter and cream', 'skin/images/menus/butter_chicken.jpg', 1470, 'Sandeep Bal', NULL),
(277, 'Chicken Curries', 'Kabuli Chicken', 'Boneless chicken with dry fruits and eggs', 'skin/images/menus/kabuli_chicken.jpg', 1700, 'Sandeep Bal', NULL),
(278, 'Chicken Curries', 'Chicken Do Pyaza', 'Boneless chicken with onion, capsicum, tomato', 'skin/images/menus/chicken_do_pyaza.jpg', 1700, 'Sandeep Bal', NULL),
(279, 'Chicken Curries', 'Kadahi Chicken', 'Stir-fried chicken with whole spices in tomato gravy', 'skin/images/menus/kadahi_chicken.jpg', 1700, 'Sandeep Bal', NULL),
(280, 'Chicken Curries', 'Chicken Jalfrezi', 'Stir-fry boneless chicken curry with vegetables', 'skin/images/menus/chicken_jalfrezi.jpg', 1700, 'Sandeep Bal', NULL),
(281, 'Chicken Curries', 'Murg Chilly', 'Indian-Chinese chicken curry with onion-capsicum', 'skin/images/menus/chicken_chilly.jpg', 1700, 'Sandeep Bal', NULL),
(282, 'Chicken Curries', 'Chicken Vindaloo', 'Spicy gravy with potato and chicken', 'skin/images/menus/chicken_vindaloo.jpg', 1700, 'Sandeep Bal', NULL),
(283, 'Mutton Curries', 'Mutton Do Pyaza', 'Boneless mutton with onion, capsicum, tomato', 'skin/images/menus/mutton_do_pyaza.jpg', 1700, 'Sandeep Bal', NULL),
(284, 'Mutton Curries', 'Mutton Shahi Masala', 'Mutton cooked with nuts and egg', 'skin/images/menus/mutton_shahi_masala.jpg', 1700, 'Sandeep Bal', NULL),
(285, 'Mutton Curries', 'Mutton Rogan Josh', 'Lamb cocked in yoghurt, onion, tomato', 'skin/images/menus/mutton_rogan_josh.jpg', 1700, 'Sandeep Bal', NULL),
(286, 'Mutton Curries', 'Keema Muttar Curry', 'Meat minced with peas and spices', 'skin/images/menus/keema_muttar_curry.jpg', 1700, 'Sandeep Bal', NULL),
(287, 'Mutton Curries', 'Saag Mutton', 'Boneless mutton cooked in spinach gravy', 'skin/images/menus/saag_mutton.jpg', 1700, 'Sandeep Bal', NULL),
(288, 'Mutton Curries', 'Bhuna Mutton', 'Marinated boneless mutton in spicy gravy', 'skin/images/menus/bhuna_mutton.jpg', 1700, 'Sandeep Bal', NULL),
(289, 'Mutton Curries', 'Mutton Korma', 'Mutton cooked with yogurt sauce', 'skin/images/menus/mutton_korma.jpg', 1700, 'Sandeep Bal', NULL),
(290, 'Mutton Curries', 'Dal Mutton', 'Mutton cooked with lentils', 'skin/images/menus/dal_mutton.jpg', 1700, 'Sandeep Bal', NULL),
(291, 'Rice', 'Plain Rice', 'Cooked Indian Rice', 'skin/images/menus/plain_rice.jpg', 600, 'Sandeep Bal', NULL),
(292, 'Rice', 'Saffron Butter Rice', 'Indian Rice cooked with saffron and butter', 'skin/images/menus/saffron_rice.jpg', 900, 'Sandeep Bal', NULL),
(293, 'Rice', 'Jeera Rice', 'Rice cooked with cumin seeds and vegetable oil', 'skin/images/menus/jeera_rice.jpg', 600, 'Sandeep Bal', NULL),
(294, 'Rice', 'Green Peas Pulao', 'Rice with green peas and cumin seeds', 'skin/images/menus/green_peas_pulao.jpg', 600, 'Sandeep Bal', NULL),
(295, 'Rice', 'Vegetable Pulao', 'Indian rice cooked with mixed vegetables', 'skin/images/menus/veg_pulao.jpg', 600, 'Sandeep Bal', NULL),
(296, 'Indian Bread', 'Plain Naan', 'Leavened, oven-baked flat bread', 'skin/images/menus/plain_naan.png', 300, 'Sandeep Bal', NULL),
(297, 'Indian Bread', 'Butter Naan', 'Leavened, oven-baked flat bread with butter', 'skin/images/menus/butter_naan.jpg', 500, 'Sandeep Bal', NULL),
(298, 'Indian Bread', 'Masala Kulcha', 'Stuffed spicy bread with green peas and potato', 'skin/images/menus/masala_kulcha.jpg', 700, 'Sandeep Bal', NULL),
(299, 'Indian Bread', 'Garlic Naan', 'Butter Naan with garlic topping', 'skin/images/menus/garlic_naan.jpg', 700, 'Sandeep Bal', NULL),
(300, 'Indian Bread', 'Puri', 'Deep fried thin flat bread', 'skin/images/menus/puri.jpg', 500, 'Sandeep Bal', NULL),
(301, 'Indian Bread', 'Prantha', 'Layered flat bread with butter cooked on flat pan', 'skin/images/menus/plain_prantha.jpg', 300, 'Sandeep Bal', NULL),
(302, 'Indian Bread', 'Bhatura', 'Deep fried thick flat bread', 'skin/images/menus/bhatura.jpg', 700, 'Sandeep Bal', NULL),
(303, 'Desserts', 'Ice Cream', 'Flavors: Vanilla, Strawberry and Chocolate', 'skin/images/menus/ice_cream.jpg', 500, 'Sandeep Bal', NULL),
(304, 'Desserts', 'Gajar Halwa', 'Carrot Pudding with dry fruits - Served warm', 'skin/images/menus/gajar_halwa.jpg', 500, 'Sandeep Bal', NULL),
(305, 'Desserts', 'Kesar Kheer', 'Sweet rice pudding with pistachio and saffron - Served warm ', 'skin/images/menus/kesar_kheer.jpg', 500, 'Sandeep Bal', NULL),
(306, 'Desserts', 'Gulab Jamun', 'Waffleballs in sugar syrup flavored with cardamom seeds and  saffron - Served warm', 'skin/images/menus/gulab_jamun.jpg', 500, 'Sandeep Bal', NULL),
(307, 'Desserts', 'Ras Malai', 'South Asian sugary, cream flattened balls of paneer soaked in  clotted cream flavored with cardamom and saffron flavor - Served cold', 'skin/images/menus/ras_malai.jpg', 500, 'Sandeep Bal', NULL),
(308, 'Beverages', 'Sweet Lassi', 'Sweetened butter-milk', 'skin/images/menus/sweet_lassi.png', 500, 'Sandeep Bal', NULL),
(309, 'Beverages', 'Mango Lasi', 'Mango flavoured butter-milk', 'skin/images/menus/mango_lassi.jpg', 500, 'Sandeep Bal', NULL),
(310, 'Beverages', 'Mango Juice', 'Juice from juicy mangoes', 'skin/images/menus/mango_juice.jpg', 500, 'Sandeep Bal', NULL),
(311, 'Raita', 'Boondi Raita', 'Tiny balls of fried chickpea flour with yogurt', 'skin/images/menus/boondi_raita.jpg', 400, 'Sandeep Bal', NULL),
(312, 'Raita', 'Mix Veg Raita', 'Yogurt with freshly cut cucumber, onion and tomato', 'skin/images/menus/mix_veg_raita.jpg', 500, 'Sandeep Bal', NULL),
(313, 'Salads', 'Green Salad', 'Made from fresh seasonal vegetables', 'skin/images/menus/green_salad.jpg', 500, 'Sandeep Bal', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `newsletter_id` int(255) NOT NULL AUTO_INCREMENT,
  `newsletter_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`newsletter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(10) NOT NULL AUTO_INCREMENT,
  `order_payment_method` varchar(50) DEFAULT NULL,
  `order_paypal_default` varchar(50) DEFAULT NULL,
  `booktable_tables` varchar(500) NOT NULL,
  `booktable_room` varchar(55) DEFAULT NULL,
  `order_type` varchar(50) NOT NULL,
  `order_comments` varchar(500) DEFAULT NULL,
  `order_catering_products` varchar(500) NOT NULL,
  `order_address` varchar(100) NOT NULL,
  `order_value` varchar(100) NOT NULL,
  `order_user_name` varchar(100) NOT NULL,
  `order_user_email` varchar(100) NOT NULL,
  `order_user_phone` int(14) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `book_date_out` varchar(50) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=577 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_payment_method`, `order_paypal_default`, `booktable_tables`, `booktable_room`, `order_type`, `order_comments`, `order_catering_products`, `order_address`, `order_value`, `order_user_name`, `order_user_email`, `order_user_phone`, `order_date`, `book_date_out`) VALUES
(256, '<div class=''label label-success''>On delivery</div>', '<div class=''label label-success''>On delivery</div>', '', NULL, 'Catering', 'No nothing', '1x - Greek food <br /> --------------------- <br /> 1x - Fish food', 'NYC, East Orange CR-434, West', '50', 'Administrator Cris Doe', 'phprestaurant-facilitator@gmail.com', 897345234, '2014-10-16 00:31:49', ''),
(264, '<div class=''label label-success''>PayPal</div>', '<div class=''label label-warning''>Unpaid</div>', '', NULL, 'Catering', 'No more ', '1x - Greek food <br /> --------------------- <br /> 1x - Fish food', 'NYC, East Orange CR-434, West', '50', 'Administrator Cris Doe', 'phprestaurant-facilitator@gmail.com', 897345234, '2014-10-16 00:42:27', ''),
(270, '<div class=''label label-success''>PayPal</div>', '<div class=''label label-success''>Paid via Paypal</', '', NULL, 'Catering', 'fasdfas', '1x - Greek food', 'NYC, East Orange CR-434, West', '14', 'Administrator Cris Doe', 'phprestaurant-facilitator@gmail.com', 897345234, '2014-10-21 17:56:13', ''),
(572, NULL, NULL, 'Table No 2', '1', 'BookATable', NULL, '', '', '', 'Mike Doe', 'phprestaurant@gmail.coma', 997345234, '2015-03-12 22:54:25', '2015-01-21 11:50:32'),
(573, NULL, NULL, 'Takeaway', '1', 'BookATable', NULL, '', '', '', 'Jane Doe', 'phprestaurant@cristianstan.co', 2147483647, '2015-03-24 23:06:40', '2015-03-25 04:06:40'),
(574, '<div class=''label label-success''>On delivery</div>', '<div class=''label label-success''>On delivery</div>', '', NULL, 'Catering', '', '1x - Chicken Manchurian <br /> --------------------- <br /> 1x - Samosa (2 Pcs.)', 'B-372, B-Block, Ranjit Avenue', '2230', 'Prakhar Bhardwaj', 'prakhar20@live.com', 0, '2015-10-28 18:17:16', ''),
(575, NULL, NULL, 'Table Nr. 04', '1', 'BookATable', NULL, '', '', '', 'Jane Doe', 'phpRestaurant@gmail.com', 2147483647, '2015-10-30 18:22:55', '2015-10-31 01:52:55'),
(576, '<div class=''label label-success''>On delivery</div>', '<div class=''label label-success''>On delivery</div>', '', NULL, 'Catering', '', '1x - Samosa (2 Pcs.) <br /> --------------------- <br /> 1x - Paneer Pakora <br /> --------------------- <br /> 1x - Veg Roll', 'New York NYC, East Orange CR-434, West', '2260', 'Jane Doe', 'phpRestaurant@gmail.com', 2147483647, '2015-10-30 18:26:16', '');

-- --------------------------------------------------------

--
-- Table structure for table `orderuser`
--

CREATE TABLE IF NOT EXISTS `orderuser` (
  `order_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  UNIQUE KEY `order_id` (`order_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `order_id_2` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderuser`
--

INSERT INTO `orderuser` (`order_id`, `user_id`) VALUES
(573, 59),
(575, 59),
(576, 59),
(574, 111);

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE IF NOT EXISTS `tables` (
  `table_id` int(10) NOT NULL AUTO_INCREMENT,
  `restaurant_room_nr` int(10) NOT NULL,
  `table_number_of_places` int(10) NOT NULL,
  `table_details` varchar(200) NOT NULL,
  `table_position` varchar(50) NOT NULL,
  `table_css_position_left` varchar(10) DEFAULT NULL,
  `table_css_position_top` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`table_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`table_id`, `restaurant_room_nr`, `table_number_of_places`, `table_details`, `table_position`, `table_css_position_left`, `table_css_position_top`) VALUES
(24, 1, 2, 'Table Nr. 04', 'Some details about this table', '80%', '80%'),
(25, 2, 4, 'Table Nr. 05', 'Some details about this table', '67%', '3%'),
(26, 2, 4, 'Table Nr. 06', 'Some details about this table', '37%', '72%'),
(39, 1, 4, 'Table Nr. 02', 'Some lorem ipsum details', '12%', '65%'),
(54, 1, 1, 'Takeaway', '', '30%', '50%');

-- --------------------------------------------------------

--
-- Table structure for table `tablesorders`
--

CREATE TABLE IF NOT EXISTS `tablesorders` (
  `tablesorders_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  PRIMARY KEY (`tablesorders_id`),
  KEY `order_id` (`order_id`),
  KEY `tablesorders_id` (`tablesorders_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tablesorders`
--

INSERT INTO `tablesorders` (`tablesorders_id`, `order_id`) VALUES
(54, 573),
(24, 575);

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE IF NOT EXISTS `testimonials` (
  `testimonial_id` int(255) NOT NULL AUTO_INCREMENT,
  `testimonal_client_name` varchar(100) DEFAULT NULL,
  `testimonial_content` longtext,
  `testimonial_client_job` varchar(255) DEFAULT NULL,
  `testimonial_thumb` varchar(255) NOT NULL,
  `testimonial_works_at` varchar(50) NOT NULL,
  PRIMARY KEY (`testimonial_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`testimonial_id`, `testimonal_client_name`, `testimonial_content`, `testimonial_client_job`, `testimonial_thumb`, `testimonial_works_at`) VALUES
(1, 'John Smith', 'The presence of good food makes positive changes in our lives.', 'Web Developer', 'skin/images/testimonials/08_01_10.jpg', 'CodeCanyon'),
(4, 'Christian Stan', 'Eat Well. Live Simple. Laugh Often.', 'Web Developer', 'skin/images/testimonials/avatar-1.jpg', 'CodeCanyon');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_role` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_nice_name` varchar(250) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_delivery_address` varchar(200) DEFAULT NULL,
  `user_phone` bigint(12) NOT NULL,
  `user_since` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_role`, `user_name`, `user_nice_name`, `user_password`, `user_email`, `user_delivery_address`, `user_phone`, `user_since`) VALUES
(59, 'Client', 'client', 'Jane Doe', '010300ed4af61c9b98a0ce35f9284df91110a73c', 'phpRestaurant@gmail.com', 'New York NYC, East Orange CR-434, West', 2147483647, '2015-10-28 09:27:13'),
(100, 'Administrator', 'sandeep', 'Sandeep Bal', 'c6ad5cedb3b8277ffc69b032b8036b86f830dfe7', 'sandeepkaurbal91@gmail.com', 'Amritsar, Punjab', 8146065027, '2015-10-29 21:55:30'),
(111, 'Administrator', 'prakhar', 'Prakhar Bhardwaj', 'c6ad5cedb3b8277ffc69b032b8036b86f830dfe7', 'prakhar20@live.com', 'Lucknow', 7696735348, '2015-10-29 21:55:45');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `menuorder`
--
ALTER TABLE `menuorder`
  ADD CONSTRAINT `menuorder_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `menuorder_ibfk_2` FOREIGN KEY (`menu_item_id`) REFERENCES `menus` (`menu_item_id`);

--
-- Constraints for table `orderuser`
--
ALTER TABLE `orderuser`
  ADD CONSTRAINT `orderuser_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `orderuser_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `tablesorders`
--
ALTER TABLE `tablesorders`
  ADD CONSTRAINT `tablesorders_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `tablesorders_ibfk_2` FOREIGN KEY (`tablesorders_id`) REFERENCES `tables` (`table_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

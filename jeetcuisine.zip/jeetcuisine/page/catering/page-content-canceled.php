<div class="container">
	<div role="alert" class="alert alert-success alert-dismissible" style="margin-bottom:30px !important">
		<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
		<?php echo $lang['paypal_canceled_message']; ?>
    </div>
</div>
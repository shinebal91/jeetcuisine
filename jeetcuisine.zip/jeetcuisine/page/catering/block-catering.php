<h1><?php echo $lang['CateringOrders']; ?></h1>
<div class="img-url-holder">
	<div class="img-url">
		<img src="<?php echo $CONF['installation_path']; ?>skin/images/3catering.jpg" alt="<?php echo $lang['CateringOrders']; ?>" />
		<div class="url-holder">
			<a class="text-center" href="<?php echo $CONF['installation_path']; ?>page/catering/" title="<?php echo $lang['CateringOrders']; ?>"><?php echo $lang['CateringOrders']; ?></a>
		    <i class="fa fa-cutlery"></i>
        </div>
	</div>
</div>
<?php 
	$query2 = mysqli_query($con, "SELECT DISTINCT menu_item_category FROM menus") or trigger_error("Query Failed: " . mysqli_error($con));
	while( $result2 = mysqli_fetch_array($query2, MYSQLI_ASSOC)) { 
		$category = $result2['menu_item_category'];
		$replace_menu_href_link = str_replace(" ","_",$category);
		$menu_href_link = strtolower($replace_menu_href_link);
		?>
	<section class="section_menus wow bounceInUp" id="<?php echo $menu_href_link; ?>">
		<?php $query3 = mysqli_query($con, "SELECT * FROM menus WHERE menu_item_category = '".$result2['menu_item_category']."' ") or trigger_error("Query Failed: " . mysqli_error($con)); 
		$num_rows = mysqli_num_rows($query3);
		?>
		<h2 class="catering_menu_title"><i class="fa fa-arrow-right"></i><?php echo $result2['menu_item_category'] . '( '. $num_rows . ' )'; ?></h2>

		<ul class="row">
			<?php while( $result3 = mysqli_fetch_array($query3, MYSQLI_ASSOC)) { ?>
			<li class="row">
				<div class="col-md-3 product_thumbnail">
					<a data-lightbox="menu-popup" href="<?php echo $CONF['installation_path'] . $result3['menu_preview_image']; ?>">
						<img class="pull-right" src="<?php echo $CONF['installation_path'] . 'system/timthumb.php?src=' . $CONF['installation_path'] . $result3['menu_preview_image'] . '&h=380&w=600&zc=1'; ?>" alt="<?php echo $result3['menu_item_name']; ?>" />
					</a>
				</div>
				<div class="col-md-9 product_body">
					<div class="row menu_title">
						<h2><?php echo $result3['menu_item_name']; ?></h2>
						<div class="clearfix"></div>
						<strong><?php echo $lang['Price'] . ":"; ?></strong>
						<?php echo $result3['menu_item_price_per_slice'] . $lang['Base_currency']; ?>
					</div>
					<div class="row menu_description">
						<strong><?php echo $lang['Details'] . ":"; ?></strong>
						<?php echo $result3['menu_item_details']; ?>
					</div>
					<div class="move_menu_item_inputs">
						<input class="single_menu_item" type="hidden" name="menu_item_id[]" value="<?php echo $result3['menu_item_id']; ?>" />
						<input disabled="disabled" class="single_menu_item menu_item_price_per_slice" type="hidden" name="menu_item_price_per_slice[]" value="<?php echo $result3['menu_item_price_per_slice']; ?>" />
						<input class="single_menu_item item_name clearfix col-md-8 form-control" readonly="readonly"  type="text" name="menu_item_name[]" value="<?php echo $result3['menu_item_name']; ?>" />
						<input class="single_menu_item temporary_price_foreach_product" type="hidden" value="" />
						<button aria-hidden="true" class="form-control remove-product-from-cart single_menu_item" type="button">×</button>

						<div class="single_menu_item col-md-2">
						    <input type="text" value="1" class="pull-left row plus-minus-qty form-control" name="plus_minus_qty[]" />
						</div>
					</div>
					<a class="add-to-cart btn-cart"><?php echo $lang['Add_to_cart']; ?> <span class="p-update-user-informations"><i class="fa fa-check"></i></span></a>
					<a class="add-to-cart-done btn-cart-done"><?php echo $lang['Added']; ?> <i class="fa fa-check"></i></a>

				</div>
			</li>
			<?php } ?>
		</ul>
	</section>
	<?php } ?>
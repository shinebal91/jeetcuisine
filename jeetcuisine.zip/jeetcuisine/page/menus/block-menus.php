<h1><?php echo $lang['MENU']; ?></h1>
<div class="img-url-holder">
	<div class="img-url">
		<img src="<?php echo $CONF['installation_path']; ?>skin/images/1menu.jpg" alt="<?php echo $lang['MENU']; ?>" />
		<div class="url-holder">
			<a class="text-center" href="<?php echo $CONF['installation_path']; ?>page/menus/" title="<?php echo $lang['MENU']; ?>"><?php echo $lang['ConsultTheMenu']; ?></a>
            <i class="fa fa-book"></i>
		</div>
	</div>
</div>
<?php
include('../../configuration.php');
$res=mysqli_query($con,"SELECT DISTINCT menu_item_category from menus");
while($row = mysqli_fetch_array($res))
{
$r=mysqli_query($con,"INSERT INTO category (cat_name) values ('".$row['menu_item_category']."')");
echo "done";

}
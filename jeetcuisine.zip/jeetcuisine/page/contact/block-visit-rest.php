<h1><?php echo $lang['VisitRest']; ?></h1>
<div class="img-url-holder">
	<div class="img-url">
		<img src="<?php echo $CONF['installation_path']; ?>skin/images/2ghungroo.jpg" alt="<?php echo $lang['VisitRest']; ?>" />
		<div class="url-holder">
			<a class="text-center" href="<?php echo $CONF['installation_path']; ?>page/contact/" title="<?php echo $lang['VisitRest']; ?>"><?php echo $lang['VisitRest']; ?></a>
            <i class="fa fa-th-large"></i>
		</div>
	</div>
</div>